import dash
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.LUX])

white_button_style = {'background-color': '#343a40',
                      'color': 'white'}


card11 = dbc.Card(
    [
        #dbc.CardImg(src=app.get_asset_url('epidemic_process_v3.png'), top=True),
        dbc.CardHeader(html.H4("Harmonized System Code (HS Code)", style={"font-size":"14px"})),
        dbc.CardBody(
            [
                html.P(
                    "If you know the 6 digit Harmonized System code of the product you are searching for, select the radio button on the left and enter the HS code. At this moment, you can only search for one HS code at a time. To learn more about HS codes, please visit the U.S. International Trade Commission website at https://www.usitc.gov/harmonized_tariff_information",
                    className="card-text",
                ),
            ],        
        ),
        dbc.CardImg(src='static/hscode_search.png', top=True, style={'width':'30%'}, className = 'align-self-center'),
    ],
)

card22 = dbc.Card(
    [
        #dbc.CardImg(src=app.get_asset_url('epidemic_process_v3.png'), top=True),
        dbc.CardHeader(html.H4("Product Description", style={"font-size":"14px"})),
        dbc.CardBody(
            [
                html.P(
                    "If you do not know the 6 digit Harmonized System code of the product you are searching for, select the radio button on the right and enter the product description. Our custom machine learning model will predict the appropriate item HS code based on your product description and retrieve business associated with that HS code accordingly.  Please be as detailed as possible.",
                    className="card-text",
                ),
            ],        
        ),
        dbc.CardImg(src='static/productdesc_search.png', top=True, style={'width':'30%'}, className = 'align-self-center'),
    ],
)

card33 = dbc.Card(
    [
        dbc.CardImg(src='static/search_buttons.png', top=True, style={'width':'50%'}, className = 'align-self-center'),
    ],
    style = {"border":"white"}
)

cardRuralUrban = dbc.Card(
    [
        dbc.CardHeader(html.H4("Rural/Urban Identifier", style={'color':'red', 'font-weight':'bold', "font-size":"14px"})),
        dbc.CardBody(
            [
                html.P(
                    "Indicates the geographic characteristics of the business’s location as defined by the U.S. Census Bureau. This allows us to potentially prioritize underrepresented business in rural parts of the United States of America.",
                    className="card-text",
                ),
            ],        
        ),
    ],
)

cardMatchPct = dbc.Card(
    [
        dbc.CardHeader(html.H4("Match %", style={'color':'blue', 'font-weight':'bold', "font-size":"14px"})),
        dbc.CardBody(
            [
                html.P(
                    "Indicates the confidence level of the predicted HS code for which the business has been retrieved.",
                    className="card-text",
                ),
            ],        
        ),
    ],
)

cardHSCode = dbc.Card(
    [
        dbc.CardHeader(html.H4("HS Code Predictions", style={'color':'green', 'font-weight':'bold', "font-size":"14px"})),
        dbc.CardBody(
            [
                html.P(
                    "Users are able to view the predicted HS codes, as well the probability of the prediction from the machine learning model and the official HS description as defined by U.S. International Trade Commission.",
                    className="card-text",
                ),
            ],        
        ),
    ],
)


cardSearchResults = dbc.Card(
    [
        dbc.CardImg(src='static/search_results.png', top=True, style={'width':'100%'}, className = 'align-self-center'),
    ],
    style = {"border":"white"}
)


layout = html.Div([
    #body,
    dbc.Container([
        dbc.Row([
            dbc.Col(html.H1("How It Works", className="text-center"), className="mb-5 mt-5")
        ]),
        dbc.Row([
            dbc.Col(html.P(
                         """\
                         Whether you are a business looking for new suppliers or looking to expand your business by identifying new potential buyers for your products, mPowerSmallBiz is here to help! Please refer to the guide below on how to optimally use our technology to grow your business!""", style={'fontSize': 20})
                    , className="mb-4")
            ]),
        dbc.Row([
            dbc.Col(html.H3("Search Criteria"), className="mb-4")
            ]),
        dbc.Row([
          dbc.Col(html.P("There are two ways to search for new businesses:", style={'fontSize': 20}), className="mb-4")
        ]),        
        dbc.Row([
            dbc.Col(card11, width=10, className="center")
          ]),
        dbc.Row(html.Br()),
        dbc.Row([
            dbc.Col(card22, width=10, className="center")
          ]),
        dbc.Row(html.Br()),
        dbc.Row([
          dbc.Col(html.H3("About our database"), className="mb-4")
        ]),
        dbc.Row([
          dbc.Col(html.P("Our database comprises of millions of U.S based businesses that offer a wide variety of products. To search for businesses that manufacture or supply your products of interest, click on 'Search Suppliers'. To search for U.S. based business that are actively purchasing your products of interest, click on 'Search Buyers'", style={'fontSize': 20}), className="mb-4")
        ]),
        dbc.Row(html.Br()),
        dbc.Row([
            dbc.Col(card33, width=10, className="center")
          ]),
        dbc.Row(html.Br()),
        dbc.Row([
          dbc.Col(html.H3("Retrieving Results"), className="mb-4")
        ]),
        dbc.Row([
          dbc.Col(html.P("Once you have entered your search criteria and selected the appropriate business type, the results will be displayed on a map, along with details such as business name and address. In addition, we have three data points displayed in the results for academic purposes as described below. All results will automatically be updated as when the map view is changed.", style={'fontSize': 20}), className="mb-4")
        ]),
        dbc.Row([
          dbc.Col(cardRuralUrban, width=10, className = "center")
          ]),
        dbc.Row(html.Br()),
        dbc.Row([
          dbc.Col(cardMatchPct, width=10, className = "center")
          ]),
        dbc.Row(html.Br()),
        dbc.Row([
          dbc.Col(cardHSCode, width=10, className = "center")
          ]),
        dbc.Row(html.Br()),
        dbc.Row([
            dbc.Col(cardSearchResults, width=10, className="center")
          ]),
    ]),

])

def HowItWorks():
    return layout

