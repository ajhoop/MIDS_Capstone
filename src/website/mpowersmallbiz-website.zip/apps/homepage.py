import dash
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html

white_button_style = {'background-color': '#343a40',
                      'color': 'white'}

inline_radioitems = dbc.FormGroup(
    [
        #dbc.Label("Search by"),
        dbc.RadioItems(
            options=[
                {"label": "HS Code", "value": 1},
                {"label": "Product description", "value": 2},
            ],
            value=2,
            id="radioitems-inline-input",
            inline=True,
            style = {'padding':'2px'}
        ),
    ]
)

radioitems = dcc.RadioItems(
    options=[
        {'label': 'HS Code', 'value': 'hscode'},
        {'label': 'Product Description', 'value': 'productdesc'},
        
    ],
    value='productdesc',
    labelStyle={'display': 'inline-block', 'margin-right':'0.5rem'},
  )


layout = html.Div([
    dbc.Container([
        dbc.Row([
            dbc.Col([html.Img(src="static/mpowerlogo-main.png", height="90px")], className="text-center", style={'padding':'20px'})
        ]),
        dbc.Row([
            dbc.Col(html.P(
                         """A digital marketplace connecting businesses across America""", style={'fontSize': 25, 'font-style': 'italic'}), 
                    className="text-center",
                    style={'padding-bottom':'100px'}),
            ]),        
        dbc.Row([
            #dbc.Col([], width=4),
            dbc.Col([dcc.Input(id='search-box-id', placeholder="Search by product description or hs code...", value='', 
                               type='text', style={'width':'inherit', 'height':'40px', 'font-style': 'italic', 'font-size':'18px'}),
                     html.Span("bfjfjf", style={"color":"white"}),
                     radioitems
                     #dbc.Form(inline_radioitems)
                     ], width=4),
        ], className="mb-5", justify="center"),
        dbc.Row([
            dbc.Col(dbc.Button("Search Suppliers",
                              id="homepage-search-button",
                              href="/suppliers",
                              color="primary",
                              className="mb-4",
                              style=white_button_style)
            , width=2, className="text-center"),
            dbc.Col(dbc.Button("Search Buyers",
                  id="homepage-search-button",
                  href="/buyers",
                  color="primary",
                  className="mb-4",
                  style=white_button_style)
            , width=2, className="text-center"),
        ], className="mb-5", justify="center"),
        dbc.Row([html.H3(id="example-output", style={'color':'red'})])
    ]),

])

def Homepage():
    return layout

app = dash.Dash(__name__, external_stylesheets = [dbc.themes.LUX])
app.layout = Homepage()
if __name__ == "__main__":
    app.run_server()


