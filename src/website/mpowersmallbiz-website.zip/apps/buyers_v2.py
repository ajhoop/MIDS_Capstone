import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc

import plotly.graph_objects as go
import pandas as pd
import numpy as np
import plotly.express as px

import dash_table as dt
import dash_leaflet as dl

white_button_style = {'background-color': '#343a40',
                      'color': 'white',
                      'padding': '3px 10px'}

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.LUX])

columns_consignee = ['Business Name', 'Address', 'Rural/Urban', 'Match %']

layout = html.Div([
    dbc.Row([
            dbc.Col([], width = 4),
            dbc.Col(html.H1("BUYERS IN USA", className="text-center"), width = 4),
            dbc.Col([], width = 4),
        ], className="mb-5 mt-5"),
    dbc.Row([
            dbc.Col([], width=4),
            dbc.Col([dcc.Input(id='input-on-submit-consignee', placeholder='Search by product description', value=None, type='text', style={'width':'inherit', 'height':'30px', 'font-style': 'italic'}),
                     html.I(id='search-string-consignee', style={'font-style': 'italic', 'font-size': '10px'})], width=4),
            dbc.Col([dbc.Button(id='submit-val-consignee', n_clicks=0, children='Submit', color="primary", className="mb-4", style=white_button_style)], width=4)
    ], className="mb-5 mt-5"),
    dbc.Row([
        dbc.Col([html.Img(src="static/legend.PNG", height="35px")])
    ]),
    dl.Map([dl.TileLayer(), dl.LayerGroup(id="layer-consignee")],
           id="map-consignee", 
           center=[38.627003, -90.199402],#[37.871666, -122.272781],
           zoom=6,
           style={"height": "50%", 'marginBottom': 25}), 
    html.Div(dt.DataTable(
                id='datatable-paging-consignee',
                columns=[{"name": i, "id": i} for i in columns_consignee],
                page_size=10,
                sort_action='native',
                style_cell={'textAlign': 'left'},
                style_data_conditional=[
                    {
                    'if': {'row_index': 'odd'},
                    'backgroundColor': 'rgb(248, 248, 248)'
                    },
                    {
                        'if': {'filter_query': '{Rural/Urban} = "Rural"',
                               'column_id': 'Rural/Urban'
                              },
                        'backgroundColor': 'salmon',
                        'color': 'white'
                    }
                ],
                style_header={
                    'backgroundColor': 'rgb(230, 230, 230)',
                    'fontWeight': 'bold',
                    'font-size': '16px'
                    },
                style_data={'whiteSpace': 'normal', 'height': 'auto', 'font-size':'16px'}
                )),
    dbc.Row([dbc.Col([])]),
    dbc.Button("Click for HS Code Predictions", id="open-centered", 
            style={'background-color': '#343a40','color': 'white','padding': '9px 18px', 'margin-top':'10px', 'margin-bottom':'10px'}),
    dbc.Modal(
        [
            dbc.ModalHeader("HS Code Predictions"),
            dbc.ModalBody(dt.DataTable(
                            id='modal-content-consignee',
                            columns=[{"name": i, "id": i} for i in list(['hscode', 'probability', 'desc'])],
                            style_cell = {'whiteSpace': 'normal', 'height':'auto'}
                        )),
            dbc.ModalFooter(
            dbc.Button("Close", id="close-centered", className="ml-auto")),
        ],id="modal-centered", centered=True,
    )
    ], style={'width': '80%', 'height': '100vh', 'margin': "auto", "display": "block"})


def Buyers2():
    print("getting Buyers2")
    return layout