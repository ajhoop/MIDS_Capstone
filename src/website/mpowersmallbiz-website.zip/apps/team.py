import plotly.graph_objects as go
import pandas as pd

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_table
import dash_bootstrap_components as dbc

white_button_style = {'background-color': '#343a40',
                      'color': 'white'}

def addTeamMember(name, title = '', blurb = '', link = ''):
    newCardBody = dbc.CardBody(
                    [
                        html.H4([html.A(name, href=link)], className="card-title"),
                        html.P(title, className="card-value", style={"text-align":"center", 'font-size':'18px'}),
                        html.P(blurb,className="card-target"),
                    ]
                ),
    return newCardBody

top_card = dbc.Card(
    [
      dbc.Col([dbc.CardImg(src="static/shaji-profile.jpg")], width=2),
      dbc.Col([dbc.CardBody(html.P("hello my name is"))], width=2)      
    ]
  )

ammaraCard = dbc.Card(addTeamMember("Ammara Essa", "Ammara is a lifelong learner and engineer passionate about novel applications of data science. \
                                     She is currently a Principal Member of Technical Staff for Radio Access Networks at Verizon. She holds a \
                                     Master of Science in Electrical Engineering from the University of California, Los Angeles and is completing her \
                                    Master of Information and Data Science from UC Berkeley.")) 

andyCard = dbc.Card(addTeamMember("Andy Hoopengardner", "Andy is an experienced management consultant and data scientist with expertise in \
                                    operational strategy and enterprise transformation. He is completing his Master of Information and Data Science \
                                    from UC Berkeley and also holds an MBA from Duke University’s Fuqua School of Business and an engineering \
                                    degree from Duke University.")) 

shajiCard = dbc.Card(addTeamMember("Shaji Kunjumohamed", "Shaji is an Engineer and a Data Scientist with 20+ years of experience in the \
                                    Semiconductor Industry.  He is passionate about creating innovative solutions that leverage both \
                                    technology and data. Shaji is completing his Master of Information and Data Science from UC Berkeley \
                                    and holds an undergraduate degree in Electronics Engineering.")) 

padmaCard = dbc.Card(addTeamMember("Padmavati Sridhar", "Padma is a Principal Software Developer and Data Scientist, experienced in working with big data \
                                    in the the automotive and finance sectors. She is passionate about new technologies and innovative in her approach \
                                    to solving large-scale data problems. Padma holds a Master of Science in Computer Science and is completing her \
                                    Master of Information and Data Science from UC Berkeley.")) 


layout = html.Div([
    dbc.Container([
        dbc.Row([
            dbc.Col(html.H1("Meet the team", className="text-center")
                    , className="mb-5 mt-5")
        ]),
        dbc.Row([
                dbc.Col([dbc.CardImg(src="static/ammara-profile.jpg")], width=2),
                dbc.Col([dbc.CardBody([html.H4("Ammara Essa", className="card-subtitle", style={'padding-bottom':'5px'}),
                                       html.P("Ammara is a lifelong learner and engineer passionate about novel applications of data science. \
                                                     She is currently a Principal Member of Technical Staff for Radio Access Networks at Verizon. She holds a \
                                                     Master of Science in Electrical Engineering from the University of California, Los Angeles and is completing her \
                                                    Master of Information and Data Science from UC Berkeley.")], style={'padding':'0px'})], width=3),
                dbc.Col([], width=1),
                dbc.Col([dbc.CardImg(src="static/andy-profile.jpg")], width=2),
                dbc.Col([dbc.CardBody([html.H4("Andy Hoopengardner", className="card-subtitle", style={'padding-bottom':'5px'}),
                                       html.P("Andy is an experienced management consultant and data scientist with expertise in \
                                                    operational strategy and enterprise transformation. He is completing his Master of Information and Data Science \
                                                    from UC Berkeley and also holds an MBA from Duke University’s Fuqua School of Business and an engineering \
                                                    degree from Duke University.")])], width=4),
          ]),
        dbc.Row([html.Br()]),
        dbc.Row([
        dbc.Col([dbc.CardImg(src="static/shaji-profile.jpg")], width=2),
        dbc.Col([dbc.CardBody([html.H4("Shaji Kunjumohamed", className="card-subtitle", style={'padding-bottom':'5px'}),
                               html.P("Shaji is an Engineer and a Data Scientist with 20+ years of experience in the \
                                    Semiconductor Industry.  He is passionate about creating innovative solutions that leverage both \
                                    technology and data. Shaji is completing his Master of Information and Data Science from UC Berkeley \
                                    and holds an undergraduate degree in Electronics Engineering.")])], width=3),
        dbc.Col([], width=1),
        dbc.Col([dbc.CardImg(src="static/padma-profile.jpg")], width=2),
        dbc.Col([dbc.CardBody([html.H4("Padmavati Sridhar", className="card-subtitle", style={'padding-bottom':'5px'}),
                                    html.P("Padma is a Principal Software Developer and Data Scientist, experienced in working with big data \
                                          in the the automotive and finance sectors. She is passionate about new technologies and innovative in her approach \
                                          to solving large-scale data problems. Padma holds a Master of Science in Computer Science and is completing her \
                                          Master of Information and Data Science from UC Berkeley.")])], width=3),
        ])

    ])

])


def Team():
    return layout