import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc

import plotly.graph_objects as go
import pandas as pd
import numpy as np
import plotly.express as px

import dash_table as dt

import geopandas as gpd
from shapely.geometry import Point


app = dash.Dash(__name__, external_stylesheets=[dbc.themes.LUX])

MAPBOX_APIKEY = "pk.eyJ1Ijoic3NvdXlyaXMiLCJhIjoiY2s5MzFlZzl2MDB2ZjNudDlhcnh6MGJsNCJ9.AefdjlX-vS_H7A83-I4sIA"
px.set_mapbox_access_token(MAPBOX_APIKEY)

layout = html.Div([
    dbc.Container([
		dbc.Row([
			dbc.Col([], width = 4),
			dbc.Col(html.H1("BUYERS IN USA", className="text-center"), width = 4),
			dbc.Col([], width = 4),
		], className="mb-5 mt-5"),
        dbc.Row([
            dbc.Col([], width=4),
            dbc.Col([html.I(id='search-string-consignee'), 
                dcc.Input(id='my-id', value=None, type='text', style={'width':'inherit'}),
                    html.Button(id='submit_button', n_clicks=0, children='Submit')], width=4),
            dbc.Col([], width=4)
        ], className="mb-5 mt-5"),
        dbc.Row([
        		dbc.Col(dcc.Graph(id="map-graph-consignee"), width=12),
                ], className="mb-5"),
        dbc.Row([dbc.Col([], width=12)]),
        dbc.Row([dbc.Col(html.Div(id="final-table-consignee"))], className="mb-5"),
        dbc.Row([dbc.Col(html.Div(id="final-table-hscode-consignee"))], className="mb-5"),
    ])

])


def Buyers():
    return layout

app.layout = Buyers()
if __name__ == "__main__":
    app.run_server()