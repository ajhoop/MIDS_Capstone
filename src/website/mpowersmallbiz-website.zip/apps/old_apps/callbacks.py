import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc

import plotly.graph_objects as go
import pandas as pd
import numpy as np
import plotly.express as px

import dash_table as dt

import geopandas as gpd
from shapely.geometry import Point

import json
import requests

#import pickle
#import xgboost as xgb

search_val = ''

print("registering callbacks")

#Base API
base_api_url = 'http://tfmodelapi.us-east-1.elasticbeanstalk.com/predict_hscode/'

#Load data for HS Codes
hs_code = pd.read_csv('data/hs_code_2019_final.csv', dtype='str')
hs_code_to_naics = pd.read_csv('data/hs6_to_naics_mapping.csv', dtype = 'str')

#Set mapbox
MAPBOX_APIKEY = "pk.eyJ1Ijoic3NvdXlyaXMiLCJhIjoiY2s5MzFlZzl2MDB2ZjNudDlhcnh6MGJsNCJ9.AefdjlX-vS_H7A83-I4sIA"
px.set_mapbox_access_token(MAPBOX_APIKEY)

#Set Threshold
THRESHOLD = 0.005

#Load SUPPLIERS - ppp data
df_naics = pd.read_csv('data/6-digit_2017_Codes.csv', dtype='str', usecols = ['2017 NAICS Code','2017 NAICS Title'], encoding = 'unicode_escape')
df_naics.columns = ['id','category']
naics_items = df_naics.to_dict('records')

df_ppp = pd.read_parquet('data/ppp_loans_naics_lat_long_sample.parq')

df_plotting = df_ppp[['BorrowerName', 'full_address', 'latitude', 'longitude', 'OfficialNAICSCode']]
df_plotting.index = np.arange(0,len(df_ppp))


#Load BUYERS - us 2019 import consignees
df_consignee = pd.read_csv('data/consignee_zipcode_df_latlong_V1_drop_dupes.csv', \
    dtype = 'str')[['Consignee Name', 'Consignee Address ', 'Cleaned_HS_Code', 'latitude', 'longitude']]
df_consignee.columns = ['Consignee Name', 'Consignee Address', 'Cleaned_HS_Code', 'latitude', 'longitude']

df_plotting_consignee = df_consignee.dropna(subset=['latitude', 'longitude'])

def get_sample_prediction(text, num_samples=10):
    print("*** I AM HERE ***")    
    print(base_api_url+text)
    r = requests.get(base_api_url + text)
    print(r.text)
    df_rank = pd.DataFrame({'probability': r.json()}).reset_index()
    df_rank.columns = ['hs', 'probability']
    df_rank = df_rank.merge(hs_code, how='left', left_on='hs', right_on='HS_Code').fillna('No description')
    df_rank.index = np.arange(1, len(df_rank) + 1)
    df_rank.columns = ['hscode', 'probability', 'hscode2', 'desc']
    df_rank.probability = df_rank.probability.astype(float)
    return df_rank.query('probability > ' + str(THRESHOLD))

def register_callbacks(app):
    @app.callback([Output('final-table-ppp', 'children'),
                   Output("map-graph-ppp", "figure"),
                   Output('final-table-hscode-ppp', 'children'),
                   Output('search-string-ppp', 'children')],
                   
              [
                Input(component_id='submit_button', component_property='n_clicks'),
                State(component_id='my-id', component_property='value')
              ])
    def update_table_suppliers(n_clicks, input_value):
        if input_value == None:
            val_to_search = search_val
        else:
            val_to_search = input_value 

        print(val_to_search)
        #Get HS Code prediction
        df_hs_code_pred = get_sample_prediction(str(val_to_search), 5)[['hscode', 'probability', 'desc']]

        naics_code = list(set(hs_code_to_naics[hs_code_to_naics.hs6.isin(list(df_hs_code_pred.hscode))].naics))

        #Get map data
        df_plotting_filtered = df_plotting[df_plotting['OfficialNAICSCode'].isin(naics_code)].head(50)

        gdf = gpd.GeoDataFrame(df_plotting_filtered,
              geometry=gpd.points_from_xy(df_plotting_filtered.longitude, 
                                          df_plotting_filtered.latitude))
        fig = px.scatter_mapbox(df_plotting_filtered,
                            lat=gdf.geometry.y,
                            lon=gdf.geometry.x,
                            hover_name="full_address",
                            zoom=4,
                            height=750)
        fig.update_geos(fitbounds="locations")

        df = px.data.iris()
        figure = px.scatter(df, x="sepal_width", y="sepal_length")

        df_filtered = df_ppp[(df_ppp["OfficialNAICSCode"].isin(naics_code))][['BorrowerName', 'full_address']].head(50)
        df_filtered.columns = ['Supplier Name', 'Supplier Address']

        return [dt.DataTable(
            style_data={'whiteSpace': 'normal', 'height': 'auto', 'font-size':'16px'},
            id='table',
            columns=[{"name": i, "id": i} for i in df_filtered.columns],
            data=df_filtered.to_dict('records'),
            page_size=10
        )], fig, [dt.DataTable(
            style_data={'whiteSpace': 'normal', 'height': 'auto', 'font-size':'16px'},
            style_cell={'maxWidth': '500px'},
            id='table',
            columns=[{"id": i, "name": i, 'name': i} for i in df_hs_code_pred.columns],
            data=df_hs_code_pred.to_dict('records'),
        )], "Currently searching for {} . Search again. ".format(val_to_search)

    # @app.callback([#Output('final-table-consignee', 'children'),
    #    #Output('final-table-hscode-consignee', 'children'),
    #    Output('search-string-consignee', 'children')],
       
    # [
    # Input(component_id='submit_button', component_property='n_clicks'),
    # State(component_id='my-id', component_property='value')
    # ])
    # def update_table_consignees(n_clicks, input_value):
    #     if input_value == None:
    #         val_to_search = search_val
    #     else:
    #         val_to_search = input_value

    #     print(val_to_search)
    #     return ["Currently searching for {} . Search again. ".format(val_to_search)]

    @app.callback([Output('final-table-consignee', 'children'),
               Output("map-graph-consignee", "figure"),
               Output('final-table-hscode-consignee', 'children'),
               Output('search-string-consignee', 'children')],
               
          [
            Input(component_id='submit_button', component_property='n_clicks'),
            State(component_id='my-id', component_property='value')
          ])
    def update_table_consignees(n_clicks, input_value):
        if input_value == None:
            val_to_search = search_val
        else:
            val_to_search = input_value

        #Get HS Code prediction
        df_hs_code_pred = get_sample_prediction(str(val_to_search), 5)[['hscode', 'probability', 'desc']]

        #Get map data
        df_plotting_filtered = df_plotting_consignee[df_plotting_consignee['Cleaned_HS_Code'].isin(list(df_hs_code_pred.head(3).hscode))].head(50)

        gdf = gpd.GeoDataFrame(df_plotting_filtered,
              geometry=gpd.points_from_xy(df_plotting_filtered.longitude, 
                                          df_plotting_filtered.latitude))
        fig = px.scatter_mapbox(df_plotting_filtered,
                            lat=gdf.geometry.y,
                            lon=gdf.geometry.x,
                            hover_name="Consignee Address",
                            zoom=4,
                            height=750)
        fig.update_geos(fitbounds="locations")

        df = px.data.iris()
        figure = px.scatter(df, x="sepal_width", y="sepal_length")

        df_temp = df_plotting_filtered[['Consignee Name', 'Consignee Address']]
        df_temp.columns = ['Buyer Name', 'Buyer Address']

        return [dt.DataTable(
            style_data={'whiteSpace': 'normal', 'height': 'auto', 'font-size':'16px'},
            id='table',
            columns=[{"name": i, "id": i} for i in df_temp.columns],
            data=df_temp.to_dict('records'),
            page_size=10
        )], fig, [dt.DataTable(
            style_data={'whiteSpace': 'normal', 'height': 'auto', 'font-size':'16px'},
            style_cell={'maxWidth': '500px'},
            id='table',
            columns=[{"id": i, "name": i, 'name': i} for i in df_hs_code_pred.columns],
            data=df_hs_code_pred.to_dict('records'),
        )], "Currently searching for {} . Search again. ".format(val_to_search)
     

    @app.callback([Output('example-output', 'children')], 
                  [Input(component_id = 'homepage-search-button', component_property = 'n_clicks'), 
                   State(component_id = 'search-box-id', component_property = 'value')])
    def search_callback(n_clicks, input_value):
        print(n_clicks, input_value)
        global search_val
        search_val = input_value
        return [search_val]