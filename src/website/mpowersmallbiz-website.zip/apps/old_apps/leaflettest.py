import json
import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
import dash_leaflet as dl
import dash_leaflet.express as dlx
import pandas as pd
import numpy as np
from dash_extensions.javascript import Namespace
from dash import Dash
from dash.dependencies import Input, Output, State

# region Data

#Load BUYERS - us 2019 import consignees
df_consignee = pd.read_csv('data/consignee_zipcode_df_latlong_V1_drop_dupes_with_counts_sample.csv')[['Consignee Name', 'Consignee Address ', 'Cleaned_HS_Code', 'state_name', 
                    'latitude', 'longitude', 'consignee_count']]
df_consignee.columns = ['Consignee Name', 'Consignee Address', 'Cleaned_HS_Code', 'state_name', 
                        'latitude', 'longitude', 'consignee_count']

#df = pd.read_csv("data/ppp_sample.csv")  # data from https://simplemaps.com/data/us-cities
df = df_consignee.dropna(subset=['latitude', 'longitude', 'state_name'])
print(df.head(1)['state_name'])
print(df['state_name'].unique())
color_prop = 'population'


def get_data(state=''):
    print("state selected" + state)
    if state == 'USA' or state == 'All':
        print("i am here!")
        df_state = df[['latitude', 'longitude', 'Consignee Name', 'consignee_count', 'Consignee Address']]
    else:
        df_state = df[df['state_name']==state][['latitude', 'longitude', 'Consignee Name', 'consignee_count', 'Consignee Address']]

    df_state.columns = ['lat', 'lng', 'city', 'population', 'density']
    dicts = df_state.to_dict('rows')
    for item in dicts:
        item["tooltip"] = item['city']  # bind tooltip
        item["popup"] = item["density"]  # bind popup
    geojson = dlx.dicts_to_geojson(dicts, lon="lng")  # convert to geojson
    geobuf = dlx.geojson_to_geobuf(geojson)  # convert to geobuf
    return geobuf


def get_minmax(state):
    df_state = df[df["state_name"] == state]  # pick one state
    return dict(min=0, max=df_state['consignee_count'].max())


# Setup a few color scales.
csc_map = {"Rainbow": ['red', 'yellow', 'green', 'blue', 'purple'],
           "Hot": ['yellow', 'red', 'black'],
           "Viridis": "Viridis"}
csc_options = [dict(label=key, value=json.dumps(csc_map[key])) for key in csc_map]


default_csc = "Rainbow"
dd_csc = dcc.Dropdown(options=csc_options, value=json.dumps(csc_map[default_csc]), id="dd_csc", clearable=False)
# Setup state options.
states = df["state_name"].unique()
state_names = [df[df["state_name"] == state]["state_name"].iloc[0] for state in states]
state_options = [dict(label=state_names[i], value=state) for i, state in enumerate(states)]
state_options = [{'label': 'USA', 'value': 'All'}] + state_options  

default_state = "All"
dd_state = dcc.Dropdown(options=state_options, value="USA", id="dd_state", clearable=False, placeholder="Select a state")

# endregion

minmax = get_minmax(default_state)
# Create geojson.
ns = Namespace("dlx", "scatter")
print(default_state)
geojson = dl.GeoJSON(data=get_data(default_state), id="geojson", format="geobuf",
                     zoomToBounds=True,  # when true, zooms to bounds when data changes
                     cluster=True,  # when true, data are clustered
                     clusterToLayer=ns("clusterToLayer"),  # how to draw clusters
                     zoomToBoundsOnClick=True,  # when true, zooms to bounds of feature (e.g. cluster) on click
                     #options=dict(pointToLayer=ns("pointToLayer")),  # how to draw points
                     superClusterOptions=dict(radius=150),  # adjust cluster size
                     #hideout=dict(colorscale=csc_map[default_csc], colorProp=color_prop, **minmax)
                     hideout=dict(colorProp=color_prop, colorscale=csc_map[default_csc], **minmax)
                     )
# Create a colorbar.
colorbar = dl.Colorbar(colorscale=csc_map[default_csc], id="colorbar", width=20, height=150, **minmax)
# Create the app.

layout = html.Div([
    dbc.Row([
        dbc.Col([], width = 4),
        dbc.Col(html.H1("BUYERS IN USA", className="text-center"), width = 4),
        dbc.Col([], width = 4),
        ], className="mb-5 mt-5"),
    dbc.Row([
        dbc.Col([], width=4),
        dbc.Col([html.I(id='search-string-consignee'), 
            dcc.Input(id='my-id', value=None, type='text', style={'width':'inherit'}),
                html.Button(id='submit_button', n_clicks=0, children='Submit')], width=4),
        dbc.Col([], width=4)
        ], className="mb-5 mt-5"),
    dl.Map([dl.TileLayer(), geojson, 
            dl.LocateControl(options={'locateOptions': {'enableHighAccuracy': True}}),
            dl.MeasureControl(position="topleft", primaryLengthUnit="kilometers", primaryAreaUnit="hectares",
                              activeColor="#214097", completedColor="#972158")]), 
    html.Div([dd_state], style={"position": "relative", "bottom": "50px", "left": "10px", "z-index": "1000", "width": "200px"}),
    html.Div(id="business"),
    dbc.Row([dbc.Col(html.Div(id="final-table-consignee"))], className="mb-5"),
    #dbc.Row([dbc.Col(html.Div(id="final-table-hscode-consignee"))], className="mb-5"),
], style={'width': '100%', 'height': '50vh', 'margin': "auto", "display": "block", "position": "relative"})


def register_callbacks_map(app):
    @app.callback(Output("business", "children"), [Input("geojson", "click_feature")])
    def business_click(feature):
        if feature is not None:
            return f"You clicked {feature['properties']['city']}"

    @app.callback([Output("geojson", "hideout"), Output("geojson", "data")],
                  [Input("dd_state", "value")])
    def update(state):
        print("state is :" +state)
        data, mm = get_data(state), get_minmax(state)
        hideout = dict(colorscale=csc_map[default_csc], colorProp=color_prop, **mm)
        return hideout, data


def LeafletTest():
    return layout