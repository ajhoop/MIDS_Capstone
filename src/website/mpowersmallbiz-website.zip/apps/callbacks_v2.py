import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc

import plotly.graph_objects as go
import pandas as pd
import numpy as np
import plotly.express as px

import dash_table as dt
import dash_leaflet as dl

import geopandas as gpd
from shapely.geometry import Point

import json
import requests

import elasticsearch
import elasticsearch_dsl

dftemp = pd.read_csv('https://raw.githubusercontent.com/plotly/datasets/master/gapminder2007.csv')

search_val = ''
location= {"top_left": {'lon': -128.94653320312503, 'lat': 40.002371935876475}, 
           "bottom_right": {'lon': -109.88525390625001, 'lat': 33.4039312002347}}
location_default= {"top_left": {'lon': -128.94653320312503, 'lat': 40.002371935876475}, 
           "bottom_right": {'lon': -109.88525390625001, 'lat': 33.4039312002347}}                  

print("registering callbacks")

#Base API
base_api_url = 'http://tfmodelapi.us-east-1.elasticbeanstalk.com/predict_hscode/'

#Load data for HS Codes
hs_code = pd.read_csv('data/hs_code_2019_final.csv', dtype='str')
hs_code_to_naics = pd.read_csv('data/hs6_to_naics_mapping.csv', dtype = 'str')

#Set Threshold
THRESHOLD = 0.005

es = elasticsearch.Elasticsearch(['http://34.217.44.96:8082'])

columns_suppliers = ['BorrowerName', 'full_address', 'latitude','longitude','location', 'RuralUrbanIndicator', 'NAICSCode', 'urban_rural-percent-rural_population-of-total_population']

columns_buyers = ['Consignee_Address', 'Raw_Consignee_Name', 'HS_Code', 'latitude', 'longitude', 'location', 'urban_rural-percent-rural_population-of-total_population']

columns_suppliers_final = ['Business Name', 'Address', 'Latitude', 'Longitude', 'Location', 'RuralUrban', 'NAICS Code', 'rural_proportion']

columns_buyers_final = ['Address', 'Business Name', 'HSCode', 'Latitude', 'Longitude', 'Location', 'rural_proportion']


df_all = pd.DataFrame(columns = columns_suppliers)    
df_all_consignees = pd.DataFrame(columns = columns_buyers)

iconpathred = {"iconUrl": 'static/map_marker_red.png'}
iconpathblue = {"iconUrl": 'static/map_marker_blue.png'}

def get_sample_prediction(text, num_samples=3):
    print(base_api_url+text)
    r = requests.get(base_api_url + text)
    df_rank = pd.DataFrame({'probability': r.json()}).reset_index()
    df_rank.columns = ['hs', 'probability']
    df_rank = df_rank.merge(hs_code, how='left', left_on='hs', right_on='HS_Code').fillna('No description')
    df_rank.index = np.arange(1, len(df_rank) + 1)
    df_rank.columns = ['hscode', 'probability', 'hscode2', 'desc']
    df_rank.probability = df_rank.probability.astype(float)
    #df_rank = df_rank.sort_values(by='probability', ascending=False)
    return df_rank.query('probability > ' + str(THRESHOLD))

def get_suppliers_elasticsearch(code = '*', ruralurban='R'):
	if ruralurban == 'R':
		request = (elasticsearch_dsl.Search(using=es, index='suppliers') \
									.filter('term', **{'urban_rural-percent-rural_population-of-total_population': 1.0}) \
									.filter("geo_bounding_box", location= location) \
									.query("match", NAICSCode=code))

	else:
		request = (elasticsearch_dsl.Search(using=es, index='suppliers') \
									.filter("geo_bounding_box", location= location) \
									.query("match", NAICSCode=code)) \
									.query("range", **{'urban_rural-percent-rural_population-of-total_population': {"gte" : 0.0, "lt" : 1.0}})


	sample = request[0:25]

	df1 = pd.DataFrame([dict((c, r[c]) for c in columns_suppliers) for r in sample])
	jsonval = df1.to_json()
	df = pd.read_json(jsonval)

	return ([dl.Marker(position=[r['latitude'], r['longitude']], 
		               children=[dl.Popup([html.H4(r['BorrowerName']),
		               	                   html.P(r['full_address'])])],  
		               icon=iconpathblue) if r['urban_rural-percent-rural_population-of-total_population']<1.0 
		else dl.Marker(position=[r['latitude'], r['longitude']], 
		               children=[dl.Popup([html.H4(r['BorrowerName']),
		               	                   html.P(r['full_address'])])],  
		               icon=iconpathred) for r in sample], df) 

def get_buyers_elasticsearch(code = '*', ruralurban='R'):
	if ruralurban == 'R':
		request = (elasticsearch_dsl.Search(using=es, index='buyers') \
									.filter("geo_bounding_box", location= location) \
									.filter('term', **{'urban_rural-percent-rural_population-of-total_population': 1.0}) \
									.query("wildcard", HS_Code=code))

	else:
		request = (elasticsearch_dsl.Search(using=es, index='buyers') \
									.filter("geo_bounding_box", location= location) \
									.query("wildcard", HS_Code=code) \
									.query("range", **{'urban_rural-percent-rural_population-of-total_population': {"gte" : 0.0, "lt" : 1.0}}))


	sample = request[0:25]

	df1 = pd.DataFrame([dict((c, r[c]) for c in columns_buyers) for r in sample])
	jsonval = df1.to_json()
	df = pd.read_json(jsonval)

	return ([dl.Marker(position=[r['latitude'], r['longitude']], 
		               children=[dl.Popup([html.H4(r['Raw_Consignee_Name']),
		               	                   html.P(r['Consignee_Address'])])], 
		               icon=iconpathblue) if r['urban_rural-percent-rural_population-of-total_population']<1.0 
		else dl.Marker(position=[r['latitude'], r['longitude']], 
		               children=[dl.Popup([html.H4(r['Raw_Consignee_Name']),
		               	                   html.P(r['Consignee_Address'])])], 
		               icon=iconpathred) for r in sample], df) 


def get_suppliers_from_naics_list(naics_list=[]):
	global df_all
	df_all = pd.DataFrame(columns = columns_suppliers)
	markers = []
	if len(naics_list)==0:
		markers, df_all = get_suppliers_elasticsearch()
	else:
		for n in naics_list:
			rural_markers, dfR = get_suppliers_elasticsearch(n, 'R')
			markers = markers + rural_markers
			df_all = df_all.append(dfR)
			urban_markers, dfU = get_suppliers_elasticsearch(n, 'U')
			markers = markers + urban_markers
			df_all = df_all.append(dfU)
	return markers


def get_buyers_from_hscode_list(hscode_list=[]):
	global df_all_consignees
	df_all_consignees = pd.DataFrame(columns = columns_buyers)
	markers = []
	if len(hscode_list)==0:
		markers, df_all_consignees = get_buyers_elasticsearch()
	else:
		for h in hscode_list:
			rural_markers, dfR = get_buyers_elasticsearch(h, 'R')
			markers = markers + rural_markers
			df_all_consignees = df_all_consignees.append(dfR)

			urban_markers, dfU = get_buyers_elasticsearch(h, 'U')
			markers = markers + urban_markers
			df_all_consignees = df_all_consignees.append(dfU)

	return markers


def register_callbacks(app):

	@app.callback([Output('example-output', 'children')], 
				[Input(component_id = 'homepage-search-button', component_property = 'n_clicks'), 
				State(component_id = 'search-box-id', component_property = 'value')])
	def search_callback(n_clicks, input_value):
		global search_val
		search_val = input_value
		return [search_val]

	@app.callback([Output("layer-ppp", "children"),
				   Output("datatable-paging-ppp", "data"),
				   Output('search-string-ppp', 'children'),
				   Output('modal-content-ppp', 'data')],
				[Input("map", "bounds")],
				[dash.dependencies.Input('submit-val-ppp', 'n_clicks')],
				[dash.dependencies.State('input-on-submit-ppp', 'value')])

	def update_output(bounds, n_clicks, value):
		if value == None or value=='':
			val_to_search = search_val
		else:
			val_to_search = value 

		v2 = {"lon": bounds[0][1],  "lat": bounds[1][0]}
		v1 = {"lon": bounds[1][1],  "lat": bounds[0][0]}

		global location
		location= {"top_left": v2, "bottom_right": v1}

		if not (-180.0 < v2['lon'] < 180.0) and (-180.0 < v1['lon'] < 180.0):
			location = location_default

		if not (-90.0 < v2['lat'] < 90.0) and (-90.0 < v1['lat'] < 90.0):
			location = location_default		

		#Get HS Code prediction
		df_hs_code_pred = get_sample_prediction(str(val_to_search), 5)[['hscode', 'probability', 'desc']]

		df_hs_code_pred = df_hs_code_pred.sort_values(by='probability', ascending=False).head(3)
		df_hs_code_pred['Match %'] = (df_hs_code_pred['probability'] / df_hs_code_pred['probability'].sum()) * 100
		df_hs_code_pred['Match %'] = [str(round(x,2))+'%' for x in df_hs_code_pred['Match %']]

		naics_code = list(set(hs_code_to_naics[hs_code_to_naics.hs6.isin(list(df_hs_code_pred.hscode))].naics))

		#Get map data
		markers = get_suppliers_from_naics_list(naics_code)

		info = "Searching for ... [{}]".format(val_to_search)

		df_all.columns = columns_suppliers_final
		df_all['Rural/Urban'] = ['Rural' if x>=0.75 else 'Urban' for x in df_all['rural_proportion']]

		tempdf = df_hs_code_pred.merge(hs_code_to_naics, right_on='hs6', left_on='hscode')[['naics', 'Match %']].drop_duplicates()
		
		tempdf['naics'] = tempdf['naics'].astype(str)
		df_all['NAICS Code'] = df_all['NAICS Code'].astype(str)

		finaldf = df_all.merge(tempdf, left_on='NAICS Code', right_on='naics')[['Business Name', 'Address', 'NAICS Code', 'Rural/Urban', 'Match %']]
		finaldf = finaldf.sort_values(by='Match %', ascending = False)
		finaldf = finaldf.drop_duplicates(subset=['Business Name', 'Address'])

		return [markers, 
				finaldf[['Business Name', 'Address', 'NAICS Code', 'Rural/Urban', 'Match %']].to_dict('records'), 
				info,
				df_hs_code_pred[['hscode', 'probability', 'desc', 'Match %']].to_dict('records')]
	

	@app.callback([Output("layer-consignee", "children"),
			   Output("datatable-paging-consignee", "data"),
			   Output('search-string-consignee', 'children'),
			   Output('modal-content-consignee', 'data')],
			[Input("map-consignee", "bounds")],
			[dash.dependencies.Input('submit-val-consignee', 'n_clicks')],
			[dash.dependencies.State('input-on-submit-consignee', 'value')])

	def update_output_consignee(bounds, n_clicks, value):
		if value == None or value=='':
			val_to_search = search_val
		else:
			val_to_search = value 

		v2 = {"lon": bounds[0][1],  "lat": bounds[1][0]}
		v1 = {"lon": bounds[1][1],  "lat": bounds[0][0]}
		
		global location
		location= {"top_left": v2, "bottom_right": v1}

		if not (-180.0 < v2['lon'] < 180.0) and (-180.0 < v1['lon'] < 180.0):
			location = location_default

		if not (-90.0 < v2['lat'] < 90.0) and (-90.0 < v1['lat'] < 90.0):
			location = location_default

		#Get HS Code prediction
		df_hs_code_pred = get_sample_prediction(str(val_to_search), 5)[['hscode', 'probability', 'desc']]

		df_hs_code_pred = df_hs_code_pred.sort_values(by='probability', ascending=False).head(3)
		df_hs_code_pred['Match %'] = (df_hs_code_pred['probability'] / df_hs_code_pred['probability'].sum()) * 100
		df_hs_code_pred['Match %'] = [str(round(x,2))+'%' for x in df_hs_code_pred['Match %']]

		#Get map data
		markers = get_buyers_from_hscode_list(list(df_hs_code_pred.hscode))

		info = "Searching for ... [{}]".format(val_to_search)

		df_all_consignees.columns = columns_buyers_final
		df_all_consignees['Rural/Urban'] = ['Rural' if x>=0.75 else 'Urban' for x in df_all_consignees['rural_proportion']]

		df_hs_code_pred['hscode'] = df_hs_code_pred['hscode'].astype(str)
		df_all_consignees['HSCode'] = df_all_consignees['HSCode'].astype(str)

		finaldf = df_all_consignees.merge(df_hs_code_pred, left_on='HSCode', right_on='hscode')[['Business Name', 'Address', 'Rural/Urban', 'Match %']]
		finaldf = finaldf.sort_values(by='Match %', ascending = False)
		finaldf = finaldf.drop_duplicates(subset=['Business Name', 'Address'])

		return [markers, 
		        finaldf[['Business Name', 'Address', 'Rural/Urban', 'Match %']].to_dict('records'), 
		        info,
		        df_hs_code_pred[['hscode', 'probability', 'desc', 'Match %']].to_dict('records')]

	@app.callback(
		Output("modal-centered", "is_open"),
		[Input("open-centered", "n_clicks"), Input("close-centered", "n_clicks")],
		[State("modal-centered", "is_open")],
		)
	def toggle_modal(n1, n2, is_open):
		if n1 or n2:
			return not is_open
		return is_open