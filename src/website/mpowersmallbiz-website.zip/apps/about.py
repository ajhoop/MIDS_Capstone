import plotly.graph_objects as go
import pandas as pd

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_table
import dash_bootstrap_components as dbc

card = dbc.Card(
    [
        dbc.CardHeader(html.H3("Motivation", style={'color':'#3c3b6e'})),
        dbc.CardBody(
            [
                html.P("mPowerSmallBiz is a marketplace that connects US small businesses with buyers. \
                	Establishing these new connections is especially important in 2021 for several reasons:", 
                	className="card-text", style={'font-size':'20px'}),
                html.Ul([html.Li("COVID-19 has caused severe supply chain disruptions that have rippled across sectors \
                	and negatively impacted US businesses. Total seasonally-adjusted US imports of goods declined from \
                	$2.5T to $2.1T in 2020. Many companies are devoting serious time, energy, and resources into \
                	re-enforcing their supply chains.", style={'font-size':'20px'}), 
                html.Br(),
                html.Li("COVID-19 negatively impacted US small businesses, with revenue down an average of 20% \
                	during the first eight months of 2020. The $940B in loans available through the Paycheck \
                	Protection Program (PPP) have helped many businesses survive, but are not likely to be \
                	a long-term solution.", style={'font-size':'20px'})])
            ],
        style={"background-color":"#f8f9fa"}),
    ],
)

card2 = dbc.Card(
    [
        dbc.CardHeader(html.H3("Product Overview", style={'color':'#3c3b6e'})),
		dbc.CardBody(
			[	            	
			html.P("The mPowerSmallBiz marketplace is powered by a specialized search engine trained using \
				natural language processing (NLP). The search engine takes in free text product descriptions \
				and predicts the appropriate Harmonized System, or HS Code. HS Codes are an international \
				standard for product classification that is administered by the World Customs Organization. \
				The codes are hierarchical, with the first two digits designating the broad category of item \
				and contain a minimum of six digits allowing for increased specificity. In 2019, there were over \
				4,200 different HS codes imported into the United States.", className="card-text", style={'font-size':'20px'}),             
			],
			style={"background-color":"#f8f9fa"}),
        dbc.CardImg(src="/static/about.png", style={"background-color":"#f8f9fa"}, className = 'align-self-center'),
        dbc.CardBody(
            [	            	              
                html.P("Once a product description has been matched to an HS Code, the mPowerSmallBiz marketplace \
                	can identify US businesses that have imported similar items based on our dataset of over 12M US \
                	Customs import records from 2019. The marketplace can also identify US small businesses capable \
                	of producing similar items by matching the HS Code to a North American Industry Classification System \
                	(NAICS) Code and then to US businesses that received PPP loans. These results are returned via an \
                	interactive interface that enables the user to explore and identify new leads, whether they are \
                	buying or selling.", className="card-text", style={'font-size':'20px'}),                
                html.A("Click here learn more on how our product works." ,href="/howitworks", className="card-text", 
                		style={'font-size':'20px', 'text-decoration': 'underline'})
            ],
        style={"background-color":"#f8f9fa"}),
    ],
)

layout = html.Div([
	dbc.Row([
            dbc.Col([], width = 4),
            dbc.Col(html.H1("ABOUT", className="text-center"), width = 4),
            dbc.Col([], width = 4),
        ], className="mb-5 mt-5"),
	dbc.Container([
		dbc.Row([
			card,
			html.Br(),
			card2
			], align='center')
		], style = {'width': '90%'})
    
])


def About():
    return layout