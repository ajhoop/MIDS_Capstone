import dash_bootstrap_components as dbc
import dash_html_components as html


def Navbar():
	navbar = dbc.Navbar(
        dbc.Row(
            [
                dbc.Col(html.Img(src="/static/mpowerlogo-blue.png", height="25px")),
            ],
            align="center",
            no_gutters=True,
        ),
	    color='#3C3B6E',
	)
	return navbar


