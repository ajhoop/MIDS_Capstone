import dash
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
#from apps.callbacks import register_callbacks 
from apps.callbacks_v2 import register_callbacks 
#from apps.leaflettest import register_callbacks_map, LeafletTest
from apps.sidebar import Sidebar, SidebarHeader
from apps.homepage import Homepage
from apps.buyers_v2 import Buyers2
#from apps.suppliers import Suppliers
from apps.suppliers_v2 import Suppliers2
from apps.team import Team
from apps.about import About
from apps.howitworks import HowItWorks
import os
import dash_auth

# Keep this out of source code repository - save in a file or a database
VALID_USERNAME_PASSWORD_PAIRS = {
    'w210capstone': 'evergreen'
}

########### Initiate the app
chroma = "https://cdnjs.cloudflare.com/ajax/libs/chroma-js/2.1.0/chroma.min.js"

app = dash.Dash(__name__,
    external_stylesheets=['https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css',
                           dbc.themes.LUX],
    # these meta_tags ensure content is scaled correctly on different devices
    # see: https://www.w3schools.com/css/css_rwd_viewport.asp for more
    meta_tags=[
        {"name": "viewport", "content": "width=device-width, initial-scale=1"}
    ],
    assets_folder ="static",
    assets_url_path="static",
    external_scripts=[chroma]
)

auth = dash_auth.BasicAuth(
    app,
    VALID_USERNAME_PASSWORD_PAIRS
)

collapseSidebar = True
application = app.server
app.title='mPowerSmallBiz-Demo'

register_callbacks(app)
#register_callbacks_map(app)
########### Set up the layout
# we use the Row and Col components to construct the sidebar header
# it consists of a title, and a toggle, the latter is hidden on large screens

# we use the Row and Col components to construct the sidebar header
# it consists of a title, and a toggle, the latter is hidden on large screens

sidebar_header = dbc.Row(
    [
        dbc.Col(html.Img(src="mpowerlogo-side.png", height="35px"), className="text-center"),
    ]
)

sbheader = SidebarHeader()

sidebar = html.Div(
    [
        sbheader,
        #sidebar_header,
        # we wrap the horizontal rule and short blurb in a div that can be
        # hidden on a small screen
        html.Div(
            [
                html.Hr(),
            ],
            id="blurb",
        ),
        # use the Collapse component to animate hiding / revealing links
        dbc.Collapse(
            dbc.Nav(
                [
                    dbc.NavLink("Home", href="/", active="exact", style={'font-size':'20px'}),
                    dbc.NavLink("About", href="/about", active="exact", style={'font-size':'20px'}),
                    dbc.NavLink("How It Works", href="/howitworks", active="exact", style={'font-size':'20px'}),
                    dbc.NavLink("➤ Search Suppliers", href="/suppliers", active="exact", style={'font-size':'20px'}),
                    dbc.NavLink("➤ Search Buyers", href="/buyers", active="exact", style={'font-size':'20px'}),
                    dbc.NavLink("Team", href="/team", active="exact", style={'font-size':'20px'}),
                ],
                vertical=True,
                pills=True,
            ),
            id="collapse",
        ),
    ],
    id="sidebar"
)

content = html.Div(id="page-content")

app.layout = html.Div([dcc.Location(id="url"), sidebar, content])


@app.callback(Output("page-content", "children"), [Input("url", "pathname")])
def render_page_content(pathname):
    if pathname == "/":
        return Homepage()
    elif pathname == '/buyers':
        return Buyers2()
    elif pathname == '/suppliers':
        print(Suppliers2())
        return Suppliers2()
    elif pathname == '/howitworks':
    	return HowItWorks()
    elif pathname == "/about":
        return About()
    elif pathname == "/team":
        return Team()
    # If the user tries to reach a different page, return a 404 message
    return dbc.Jumbotron(
    [
    html.H1("404: Not found", className="text-danger"),
    html.Hr(),
    html.P(f"The pathname {pathname} was not recognised..."),
    ]
    )


# @app.callback(
#     Output("sidebar", "className"),
#     [Input("sidebar-toggle", "n_clicks")],
#     [State("sidebar", "className")],
# )
# def toggle_classname(n, classname):
# 	print("toggle classname is {}".format(n))
# 	if n is None:
# 		print("returning COLLAPSED")
# 		return "collapsed"
# 	if n and classname == "":
# 		print("returning COLLAPSED")
# 		return "collapsed"
# 	return ""


@app.callback(
    Output("sidebar", "className"),
    [Input("sidebar-toggle", "n_clicks")],
    [State("sidebar", "className")],
)
def toggle_classname(n, classname):
	if n is None:
		return ""
	if n is not None and classname == 'collapsed':
		return ""
	else:
		return "collapsed"
	
@app.callback(
    Output("collapse", "is_open"),
    [Input("navbar-toggle", "n_clicks")],
    [State("collapse", "is_open")],
)
def toggle_collapse(n, is_open):
    if n:
        return not is_open
    return is_open
########### Run the app
if __name__ == '__main__':
    application.run(debug=True, port=8080)